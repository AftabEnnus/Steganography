/*
Name: Shaikh Aftab Ennus
Date: 11/10/2024
Description: LSB Image Steganography
Sample input:
Sample output:
*/
#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include<unistd.h>
#define RESET   "\033[0m" // this all are for coloring purpose
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
int main(int argc,char *argv[])
{
    EncodeInfo encInfo;
    DecodeInfo decInfo;
    uint img_size;   
    if(argc<3)
    {
	    printf(RED"Invalid arguments provided! Please enter valid arguments for encoding or decoding.\n"
       "Usage:\n"
       "  For encoding: ./a.out -e <source_image.bmp> <secret_file.txt> <stego_image.bmp>\n"
       "  For decoding: ./a.out -d <stego_image.bmp> <output_file>\n"
       "Example:\n"
       "  Encoding: ./a.out -e source.bmp secret.txt output.bmp\n"
       "  Decoding: ./a.out -d stego.bmp output\n"RESET
       YELLOW"Please try again with the correct format.\n"RESET);

        return 1;
    }
    if(check_operation_type(argv)==e_encode)
    {
        printf(GREEN"INFO: Encoding started.................\n"RESET);
	sleep(1);
        if(read_and_validate_encode_args(argv,&encInfo)==e_success)
        {
            printf(GREEN"\nINFO: validated succesfully\n"RESET);
	    sleep(1);
            if(do_encoding(&encInfo)==e_success)
            {
                printf(GREEN"\nINFO: ...............Encoded successfully!\n"RESET);
		sleep(1);
            } 
            else
            {
                printf(RED"Sorry encoding was not possible\n"RESET);
            }
        }
        else
        {
            printf(RED"Failed to Validate\n"RESET);
        }
    }
    else if(check_operation_type(argv)==e_decode)
    {
        printf(GREEN"INFO: Decoding started..................\n"RESET);  
	sleep(1);
        if(read_and_validate_decode_args(argv,&decInfo)==d_success)
        {
            printf(GREEN"\nINFO: File Validate successfully\n"RESET);
	    sleep(1);
            if(do_decoding(&decInfo)==d_success)
            {
                printf(GREEN"\nINFO: ................Decoded successfully!\n"RESET);
		sleep(1);
            }
            else
            {
                printf(RED"Sorry decoding was not possible\n"RESET);
            }
        }
        else
        {
            printf(RED"Usage: Fail decode"RESET);
        }
    }
    else
    {
        printf(RED"Usage:\\ (-e,-d ) Please enter correct value:\n "RESET);
    }

    return 0;
}
